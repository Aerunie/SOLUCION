package aegisid.config;

import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;
import java.sql.Connection;
import java.sql.Statement;

@WebListener
public class DatabaseInitializer implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             Statement st = conn.createStatement()) {

            st.executeUpdate("CREATE TABLE IF NOT EXISTS usuarios ("
                + "id_usuario INT AUTO_INCREMENT PRIMARY KEY, "
                + "correo VARCHAR(100) NOT NULL UNIQUE, "
                + "clave VARCHAR(100) NOT NULL, "
                + "rol VARCHAR(50) DEFAULT 'Administrador', "
                + "estado VARCHAR(15) DEFAULT 'Activo', "
                + "intentos_fallidos INT DEFAULT 0, "
                + "bloqueado BOOLEAN DEFAULT FALSE)");

            // Por si la tabla ya existía con menos columnas
            agregarColumna(st, "ALTER TABLE usuarios ADD COLUMN rol VARCHAR(50) DEFAULT 'Administrador'");
            agregarColumna(st, "ALTER TABLE usuarios ADD COLUMN estado VARCHAR(15) DEFAULT 'Activo'");
            agregarColumna(st, "ALTER TABLE usuarios ADD COLUMN intentos_fallidos INT DEFAULT 0");
            agregarColumna(st, "ALTER TABLE usuarios ADD COLUMN bloqueado BOOLEAN DEFAULT FALSE");

            st.executeUpdate("INSERT IGNORE INTO usuarios (correo, clave, intentos_fallidos, bloqueado) "
                + "VALUES ('admin@correo.com', '1234', 0, FALSE)");

            st.executeUpdate("CREATE TABLE IF NOT EXISTS clientes ("
                + "id_cliente INT AUTO_INCREMENT PRIMARY KEY, "
                + "nombre VARCHAR(150) NOT NULL, "
                + "correo VARCHAR(100) NOT NULL UNIQUE, "
                + "telefono VARCHAR(20), "
                + "direccion VARCHAR(200), "
                + "estado VARCHAR(15) DEFAULT 'Activo')");

            st.executeUpdate("CREATE TABLE IF NOT EXISTS proveedores ("
                + "id_proveedor INT AUTO_INCREMENT PRIMARY KEY, "
                + "razon_social VARCHAR(150) NOT NULL, "
                + "correo VARCHAR(100) NOT NULL UNIQUE, "
                + "telefono VARCHAR(20), "
                + "categoria VARCHAR(100), "
                + "estado VARCHAR(15) DEFAULT 'Activo')");

            st.executeUpdate("CREATE TABLE IF NOT EXISTS productos ("
                + "id_producto INT AUTO_INCREMENT PRIMARY KEY, "
                + "nombre VARCHAR(150) NOT NULL, "
                + "categoria VARCHAR(100) NOT NULL, "
                + "precio DECIMAL(10,2) NOT NULL, "
                + "stock INT NOT NULL, "
                + "estado VARCHAR(15) DEFAULT 'Disponible')");

            st.executeUpdate("CREATE TABLE IF NOT EXISTS ventas ("
                + "id_venta INT AUTO_INCREMENT PRIMARY KEY, "
                + "cliente VARCHAR(150) NOT NULL, "
                + "total DECIMAL(10,2) NOT NULL, "
                + "metodo_pago VARCHAR(50) NOT NULL, "
                + "fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void agregarColumna(Statement st, String sql) {
        try { st.executeUpdate(sql); } catch (Exception ignorada) { /* la columna ya existe */ }
    }
}