package aegisid.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    public static DatabaseConnection getInstance() {
        return new DatabaseConnection();
    }

    public Connection getConnection() throws SQLException {
        try {
            String host = "DESKTOP-UT2NPIQ";
            String db = "AegisID_DB";
            
            // Conexión estricta por TCP/IP en el puerto 1436 sin autenticación de Windows
            String url = "jdbc:sqlserver://" + host + ":1436;databaseName=" + db + ";encrypt=true;trustServerCertificate=true;";

            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            
            // Forzamos el usuario y contraseña puros de SQL Server
            return DriverManager.getConnection(url, "admin_app", "1234");
            
        } catch (ClassNotFoundException e) {
            throw new SQLException("No se encontró el Driver de SQL Server: " + e.getMessage(), e);
        }
    }
}